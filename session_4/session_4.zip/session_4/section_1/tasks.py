#------------------------------------------------------------------------------#
# (1)
# Write min. 2 functions which handle the reading, processing and visualization 
# of a time series of transactions for one location (dependet on an argument) 
# (you can use the sum, mean or median) for the transactions on one day.



# test your function(s) for <Coffee Cameleon> and <Brew've Been Served>
# plot("Coffee Cameleon")
# plot("Brew've Been Served")


# (2) - optional
# Create a heatmap (https://seaborn.pydata.org/generated/seaborn.heatmap.html)
# using seaborn for every location (y) and every date (x) and the 
# sum of the price on the specific day (z).
# Hints: 1 - first build a list of dictionaires and convert it then to 
# a df to visualize
# 2 - use iterrows in this way to iterate through a df:
#   for index, row in df.iterrows:
#       row.location


        
        
        
        
