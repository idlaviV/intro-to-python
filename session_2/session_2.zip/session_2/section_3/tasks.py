#------------------------------------------------------------------------------#
# (1) 
# hint
s = "Hallo"
print(s.lower())
names = ["Tilman", "Clara", "Maria", "Iven", "Emma", "Mo"]

# Lower all names in the names list



# Filter all names which include 2 'a':


#------------------------------------------------------------------------------#
# (2) 
# Create a class for traffic light and come up with two properties.
# Implement a method for phase switching



# Init a traffic light object and switch the phase 2 times