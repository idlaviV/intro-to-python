
#------------------------------------------------------------------------------#
# (1)
# Write a function which simulates the for loop without using any loop



#------------------------------------------------------------------------------#
# (2)
# Write a function which simulates the for sum function