#------------------------------------------------------------------------------#
# (1)
# Read the credit card data

# convert the price colum to a float, last4ccnum to an int


# split the timestamp into date and time


# round the price in every row (however you like)


#------------------------------------------------------------------------------#
# (2)
# Determine where the most money got spent (at which location)
# use groupby


# Determine the mean money spent at every location