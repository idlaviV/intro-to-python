# importing a helper function
from helper import prep_data
#------------------------------------------------------------------------------#
# (1)
# Load the first chapter of harry potter


# After loading pass the string contents to the prep_data function:
data = prep_data(string_content)

# print out the keys for the dictionary


# Count the number of mentions of potter and harry in the text.


# Count the number of mentions of potter and harry in the tokens
# using the filter function


# write your different results to a json file

#------------------------------------------------------------------------------#
# (2)
# Write a function which takes a category (of questions - math or sport) and then prompts the
# respective question. Then show the user the different options and 
# let him guess and evaluate his answer.

